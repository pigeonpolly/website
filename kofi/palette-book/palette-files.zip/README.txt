Pigeon Polly Art Lab: 172 Color Palettes

procreate/     one .swatches per palette: AirDrop or tap on iPad to import
adobe-affinity/ .ase libraries: Photoshop/Illustrator Swatches panel > Import Swatches; Affinity: Swatches > Import Palette
krita-gimp/   .gpl palettes: Krita Palette docker > Import; GIMP Palettes > Import; Inkscape: copy to palettes folder
hex-codes.csv every color in one table

Colors: free for personal and commercial use. Artwork © Alina Otkinska. Please do not resell or share these files.
pigeonpolly.com
